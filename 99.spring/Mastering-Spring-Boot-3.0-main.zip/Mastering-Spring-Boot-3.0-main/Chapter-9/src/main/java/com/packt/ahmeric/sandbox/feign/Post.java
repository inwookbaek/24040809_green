package com.packt.ahmeric.sandbox.feign;

public record Post(int userId, int id, String title, String body) { }
