package com.packt.ahmeric.reactivesample.model.dto;

public record LoginRequestDto(String username, String password) {
}
