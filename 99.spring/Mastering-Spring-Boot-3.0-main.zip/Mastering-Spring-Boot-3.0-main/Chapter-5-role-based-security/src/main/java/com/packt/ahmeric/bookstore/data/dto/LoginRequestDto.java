package com.packt.ahmeric.bookstore.data.dto;

public record LoginRequestDto(String username, String password) {
}
