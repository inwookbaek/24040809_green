package com.packt.ahmeric.bookstorebatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstorebatchApplicationTests {

    @Test
    void contextLoads() {
    }

}
