package com.packt.ahmeric.bookstorebatch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookstorebatchApplication {

    public static void main(String[] args) {
        SpringApplication.run(BookstorebatchApplication.class, args);
    }

}
