package com.packt.ahmeric.reactivesample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveSampleApplicationTests {

    @Test
    void contextLoads() {
    }

}
