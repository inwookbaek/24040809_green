#!/bin/bash
while true; do
  curl http://localhost:8080/message
  sleep 10
done
