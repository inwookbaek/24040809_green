CREATE TABLE IF NOT EXISTS users (
                                     id INT PRIMARY KEY AUTO_INCREMENT,
                                     name VARCHAR(100),
                                     email VARCHAR(100)
);
